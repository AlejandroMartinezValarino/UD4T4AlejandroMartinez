var searchData=
[
  ['nfloat_0',['nfloat',['../net8_80-ios_2iossimulator-x64_2_u_d4_t4_alejandro_martinez_8nfloat_8g_8cs.html#a5a9fdee2373fc925da61b334ab3b1fda',1,'nfloat:&#160;UD4T4AlejandroMartinez.nfloat.g.cs'],['../net8_80-maccatalyst_2maccatalyst-x64_2_u_d4_t4_alejandro_martinez_8nfloat_8g_8cs.html#a5a9fdee2373fc925da61b334ab3b1fda',1,'nfloat:&#160;UD4T4AlejandroMartinez.nfloat.g.cs']]]
];
