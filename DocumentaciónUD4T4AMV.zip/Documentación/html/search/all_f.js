var searchData=
[
  ['printalumno_0',['PrintAlumno',['../class_u_d4_t4_alejandro_martinez_1_1_m_v_v_m_1_1_view_models_1_1_alumno_view_model.html#a56b86537396e5af5d1e75f1eb2daef6d',1,'UD4T4AlejandroMartinez::MVVM::ViewModels::AlumnoViewModel']]],
  ['printcommand_1',['PrintCommand',['../class_u_d4_t4_alejandro_martinez_1_1_m_v_v_m_1_1_view_models_1_1_alumno_view_model.html#afed95ff4c906c776436565c6c29c1bbc',1,'UD4T4AlejandroMartinez::MVVM::ViewModels::AlumnoViewModel']]],
  ['processstudenttemplatepdf_2',['ProcessStudentTemplatePDF',['../class_u_d4_t4_alejandro_martinez_1_1_m_v_v_m_1_1_view_models_1_1_alumno_view_model.html#a58d10214b533c059c942eafd9e220b51',1,'UD4T4AlejandroMartinez::MVVM::ViewModels::AlumnoViewModel']]],
  ['profesor_3',['Profesor',['../class_u_d4_t4_alejandro_martinez_1_1_m_v_v_m_1_1_models_1_1_profesor.html',1,'UD4T4AlejandroMartinez::MVVM::Models']]],
  ['profesor_2ecs_4',['Profesor.cs',['../_profesor_8cs.html',1,'']]],
  ['profesorseguimiento_5',['ProfesorSeguimiento',['../class_u_d4_t4_alejandro_martinez_1_1_m_v_v_m_1_1_models_1_1_alumno.html#afe5fed793d15d0f379ae7104dd674479',1,'UD4T4AlejandroMartinez::MVVM::Models::Alumno']]],
  ['program_6',['Program',['../class_u_d4_t4_alejandro_martinez_1_1_program.html',1,'UD4T4AlejandroMartinez']]],
  ['program_2ecs_7',['program.cs',['../i_o_s_2_program_8cs.html',1,'(Global Namespace)'],['../_mac_catalyst_2_program_8cs.html',1,'(Global Namespace)']]],
  ['propertychanged_8',['propertychanged',['../class_u_d4_t4_alejandro_martinez_1_1_m_v_v_m_1_1_view_models_1_1_alumno_view_model.html#aca40f6d6a75c915be1f45ac14f4f0c73',1,'UD4T4AlejandroMartinez.MVVM.ViewModels.AlumnoViewModel.PropertyChanged'],['../class_u_d4_t4_alejandro_martinez_1_1_m_v_v_m_1_1_view_models_1_1_dia_view_model.html#a6cf5ebad173acd3964b40e6f9bd4d994',1,'UD4T4AlejandroMartinez.MVVM.ViewModels.DiaViewModel.PropertyChanged']]],
  ['provider_9',['Provider',['../class_u_d4_t4_alejandro_martinez_1_1_u_d4_t4_alejandro_martinez___xaml_type_info_1_1_xaml_meta_data_provider.html#a5ec2112dfd03261fa23624b943ad091c',1,'UD4T4AlejandroMartinez::UD4T4AlejandroMartinez_XamlTypeInfo::XamlMetaDataProvider']]]
];
