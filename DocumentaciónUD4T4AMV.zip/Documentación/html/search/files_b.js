var searchData=
[
  ['week_2examl_2ecs_0',['Week.xaml.cs',['../_week_8xaml_8cs.html',1,'']]]
];
