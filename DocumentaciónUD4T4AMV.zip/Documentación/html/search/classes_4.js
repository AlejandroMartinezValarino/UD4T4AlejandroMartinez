var searchData=
[
  ['mainactivity_0',['MainActivity',['../class_u_d4_t4_alejandro_martinez_1_1_main_activity.html',1,'UD4T4AlejandroMartinez']]],
  ['mainapplication_1',['MainApplication',['../class_u_d4_t4_alejandro_martinez_1_1_main_application.html',1,'UD4T4AlejandroMartinez']]],
  ['mainpage_2',['MainPage',['../class_u_d4_t4_alejandro_martinez_1_1_main_page.html',1,'UD4T4AlejandroMartinez']]]
];
