var searchData=
[
  ['targettype_0',['TargetType',['../class_u_d4_t4_alejandro_martinez_1_1_u_d4_t4_alejandro_martinez___xaml_type_info_1_1_xaml_member.html#a2efdb89d87d11be8342c0f8cb3275cbb',1,'UD4T4AlejandroMartinez::UD4T4AlejandroMartinez_XamlTypeInfo::XamlMember']]],
  ['tiempo_1',['Tiempo',['../class_u_d4_t4_alejandro_martinez_1_1_m_v_v_m_1_1_models_1_1_dia.html#a5a751e0f58a0f325f45ad662f9f1e209',1,'UD4T4AlejandroMartinez::MVVM::Models::Dia']]],
  ['tutortrabajo_2',['TutorTrabajo',['../class_u_d4_t4_alejandro_martinez_1_1_m_v_v_m_1_1_models_1_1_alumno.html#ad21d8a7c735dacce9592168edec3fcdc',1,'UD4T4AlejandroMartinez::MVVM::Models::Alumno']]],
  ['type_3',['Type',['../class_u_d4_t4_alejandro_martinez_1_1_u_d4_t4_alejandro_martinez___xaml_type_info_1_1_xaml_member.html#af46338c8f64c4ceddbc244d882bf64dc',1,'UD4T4AlejandroMartinez::UD4T4AlejandroMartinez_XamlTypeInfo::XamlMember']]]
];
