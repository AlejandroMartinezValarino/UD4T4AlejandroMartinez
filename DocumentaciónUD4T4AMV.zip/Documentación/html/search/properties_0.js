var searchData=
[
  ['_5fappprovider_0',['_AppProvider',['../class_u_d4_t4_alejandro_martinez_1_1_win_u_i_1_1_app.html#ae8645072ae9390bf8628dcfb90f947c7',1,'UD4T4AlejandroMartinez::WinUI::App']]]
];
