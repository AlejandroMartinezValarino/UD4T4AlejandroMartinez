var searchData=
[
  ['client_0',['client',['../class_u_d4_t4_alejandro_martinez_1_1_m_v_v_m_1_1_view_models_1_1_alumno_view_model.html#abbb376a32c4718206d900b2897a4cde2',1,'UD4T4AlejandroMartinez.MVVM.ViewModels.AlumnoViewModel.client'],['../class_u_d4_t4_alejandro_martinez_1_1_m_v_v_m_1_1_views_1_1_day.html#ab5fd00b76c19cf097105a47ecc057f2a',1,'UD4T4AlejandroMartinez.MVVM.Views.Day.client'],['../class_u_d4_t4_alejandro_martinez_1_1_m_v_v_m_1_1_views_1_1_login.html#a129ea9ab3edb69a4e30037502b301d61',1,'UD4T4AlejandroMartinez.MVVM.Views.Login.client'],['../class_u_d4_t4_alejandro_martinez_1_1_m_v_v_m_1_1_views_1_1_register.html#a2eb1c4ef7736e43dd0a5ffa9499b53e3',1,'UD4T4AlejandroMartinez.MVVM.Views.Register.client']]],
  ['count_1',['count',['../class_u_d4_t4_alejandro_martinez_1_1_main_page.html#a695c77ad7caa1b0f13c0b82e753c7e9b',1,'UD4T4AlejandroMartinez::MainPage']]]
];
