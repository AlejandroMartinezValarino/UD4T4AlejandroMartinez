var searchData=
[
  ['profesor_2ecs_0',['Profesor.cs',['../_profesor_8cs.html',1,'']]],
  ['program_2ecs_1',['program.cs',['../i_o_s_2_program_8cs.html',1,'(Global Namespace)'],['../_mac_catalyst_2_program_8cs.html',1,'(Global Namespace)']]]
];
