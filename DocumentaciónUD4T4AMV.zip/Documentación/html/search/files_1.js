var searchData=
[
  ['_5f_5fmicrosoft_2eandroid_2eresource_2edesigner_2ecs_0',['__Microsoft.Android.Resource.Designer.cs',['../_____microsoft_8_android_8_resource_8_designer_8cs.html',1,'']]]
];
