var searchData=
[
  ['semana_0',['Semana',['../class_u_d4_t4_alejandro_martinez_1_1_m_v_v_m_1_1_models_1_1_semana.html',1,'UD4T4AlejandroMartinez::MVVM::Models']]],
  ['student_1',['Student',['../class_u_d4_t4_alejandro_martinez_1_1_m_v_v_m_1_1_views_1_1_student.html',1,'UD4T4AlejandroMartinez::MVVM::Views']]]
];
