var searchData=
[
  ['observaciones_0',['Observaciones',['../class_u_d4_t4_alejandro_martinez_1_1_m_v_v_m_1_1_models_1_1_dia.html#a78ef8bdbb3bf61ddb0aec4efd601fe82',1,'UD4T4AlejandroMartinez::MVVM::Models::Dia']]],
  ['otherproviders_1',['OtherProviders',['../class_u_d4_t4_alejandro_martinez_1_1_u_d4_t4_alejandro_martinez___xaml_type_info_1_1_xaml_type_info_provider.html#aef6907f749a80d837d1bf4128c68d0ec',1,'UD4T4AlejandroMartinez::UD4T4AlejandroMartinez_XamlTypeInfo::XamlTypeInfoProvider']]]
];
