var searchData=
[
  ['dian_0',['DiaN',['../class_u_d4_t4_alejandro_martinez_1_1_m_v_v_m_1_1_models_1_1_dia.html#af94779fda6a769dd2dcf225333b7399a',1,'UD4T4AlejandroMartinez::MVVM::Models::Dia']]],
  ['dias_1',['dias',['../class_u_d4_t4_alejandro_martinez_1_1_m_v_v_m_1_1_models_1_1_semana.html#a810b83340d8411f813de11d72ad51e93',1,'UD4T4AlejandroMartinez.MVVM.Models.Semana.Dias'],['../class_u_d4_t4_alejandro_martinez_1_1_m_v_v_m_1_1_view_models_1_1_dia_view_model.html#a796244a7d039bf0b85b362cc8b0ae028',1,'UD4T4AlejandroMartinez.MVVM.ViewModels.DiaViewModel.Dias']]],
  ['dictionaryadd_2',['DictionaryAdd',['../class_u_d4_t4_alejandro_martinez_1_1_u_d4_t4_alejandro_martinez___xaml_type_info_1_1_xaml_user_type.html#abf09e40ba085934d37ef90b0d2b44fe5',1,'UD4T4AlejandroMartinez::UD4T4AlejandroMartinez_XamlTypeInfo::XamlUserType']]]
];
