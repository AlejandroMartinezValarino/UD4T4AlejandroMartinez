var searchData=
[
  ['sksvg_0',['SKSvg',['../_alumno_view_model_8cs.html#a62de4693be6296992910e880d1b56964',1,'AlumnoViewModel.cs']]]
];
