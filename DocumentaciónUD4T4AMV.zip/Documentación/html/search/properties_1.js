var searchData=
[
  ['activator_0',['Activator',['../class_u_d4_t4_alejandro_martinez_1_1_u_d4_t4_alejandro_martinez___xaml_type_info_1_1_xaml_user_type.html#a8f9c796f1e4a2c43b1d7cf426c4ec2a2',1,'UD4T4AlejandroMartinez::UD4T4AlejandroMartinez_XamlTypeInfo::XamlUserType']]],
  ['actividad_1',['Actividad',['../class_u_d4_t4_alejandro_martinez_1_1_m_v_v_m_1_1_models_1_1_dia.html#a37e7de5a67b134ff7358a155090b66d6',1,'UD4T4AlejandroMartinez::MVVM::Models::Dia']]],
  ['alumnoactual_2',['AlumnoActual',['../class_u_d4_t4_alejandro_martinez_1_1_m_v_v_m_1_1_view_models_1_1_alumno_view_model.html#a6982e3afc9abe4b938dd0df9ca70c3ae',1,'UD4T4AlejandroMartinez::MVVM::ViewModels::AlumnoViewModel']]],
  ['alumnos_3',['Alumnos',['../class_u_d4_t4_alejandro_martinez_1_1_m_v_v_m_1_1_view_models_1_1_alumno_view_model.html#aa28a100ea26f6a71e41b3e8bb4f9110e',1,'UD4T4AlejandroMartinez::MVVM::ViewModels::AlumnoViewModel']]]
];
