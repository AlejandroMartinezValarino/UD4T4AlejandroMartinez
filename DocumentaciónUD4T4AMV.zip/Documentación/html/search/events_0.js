var searchData=
[
  ['propertychanged_0',['propertychanged',['../class_u_d4_t4_alejandro_martinez_1_1_m_v_v_m_1_1_view_models_1_1_alumno_view_model.html#aca40f6d6a75c915be1f45ac14f4f0c73',1,'UD4T4AlejandroMartinez.MVVM.ViewModels.AlumnoViewModel.PropertyChanged'],['../class_u_d4_t4_alejandro_martinez_1_1_m_v_v_m_1_1_view_models_1_1_dia_view_model.html#a6cf5ebad173acd3964b40e6f9bd4d994',1,'UD4T4AlejandroMartinez.MVVM.ViewModels.DiaViewModel.PropertyChanged']]]
];
