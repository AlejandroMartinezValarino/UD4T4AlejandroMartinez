var searchData=
[
  ['underlyingtype_0',['UnderlyingType',['../class_u_d4_t4_alejandro_martinez_1_1_u_d4_t4_alejandro_martinez___xaml_type_info_1_1_xaml_system_base_type.html#ad89a10164334087daafcd1ed1279dcaf',1,'UD4T4AlejandroMartinez::UD4T4AlejandroMartinez_XamlTypeInfo::XamlSystemBaseType']]]
];
