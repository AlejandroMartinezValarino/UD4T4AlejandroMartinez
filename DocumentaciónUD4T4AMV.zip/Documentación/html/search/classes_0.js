var searchData=
[
  ['alumno_0',['Alumno',['../class_u_d4_t4_alejandro_martinez_1_1_m_v_v_m_1_1_models_1_1_alumno.html',1,'UD4T4AlejandroMartinez::MVVM::Models']]],
  ['alumnoviewmodel_1',['AlumnoViewModel',['../class_u_d4_t4_alejandro_martinez_1_1_m_v_v_m_1_1_view_models_1_1_alumno_view_model.html',1,'UD4T4AlejandroMartinez::MVVM::ViewModels']]],
  ['app_2',['app',['../class_u_d4_t4_alejandro_martinez_1_1_app.html',1,'UD4T4AlejandroMartinez.App'],['../class_u_d4_t4_alejandro_martinez_1_1_win_u_i_1_1_app.html',1,'UD4T4AlejandroMartinez.WinUI.App']]],
  ['appdelegate_3',['AppDelegate',['../class_u_d4_t4_alejandro_martinez_1_1_app_delegate.html',1,'UD4T4AlejandroMartinez']]],
  ['appshell_4',['AppShell',['../class_u_d4_t4_alejandro_martinez_1_1_app_shell.html',1,'UD4T4AlejandroMartinez']]]
];
