var searchData=
[
  ['main_2ecs_0',['Main.cs',['../_main_8cs.html',1,'']]],
  ['mainactivity_2ecs_1',['MainActivity.cs',['../_main_activity_8cs.html',1,'']]],
  ['mainapplication_2ecs_2',['MainApplication.cs',['../_main_application_8cs.html',1,'']]],
  ['mainpage_2examl_2ecs_3',['MainPage.xaml.cs',['../_main_page_8xaml_8cs.html',1,'']]],
  ['mauiprogram_2ecs_4',['MauiProgram.cs',['../_maui_program_8cs.html',1,'']]]
];
