var searchData=
[
  ['profesor_0',['Profesor',['../class_u_d4_t4_alejandro_martinez_1_1_m_v_v_m_1_1_models_1_1_profesor.html',1,'UD4T4AlejandroMartinez::MVVM::Models']]],
  ['program_1',['Program',['../class_u_d4_t4_alejandro_martinez_1_1_program.html',1,'UD4T4AlejandroMartinez']]]
];
