var searchData=
[
  ['alumno_2ecs_0',['Alumno.cs',['../_alumno_8cs.html',1,'']]],
  ['alumnoviewmodel_2ecs_1',['AlumnoViewModel.cs',['../_alumno_view_model_8cs.html',1,'']]],
  ['app_2eg_2ecs_2',['App.g.cs',['../_app_8g_8cs.html',1,'']]],
  ['app_2eg_2ei_2ecs_3',['App.g.i.cs',['../_app_8g_8i_8cs.html',1,'']]],
  ['app_2examl_2ecs_4',['app.xaml.cs',['../_app_8xaml_8cs.html',1,'(Global Namespace)'],['../_platforms_2_windows_2_app_8xaml_8cs.html',1,'(Global Namespace)']]],
  ['appdata_2ecs_5',['AppData.cs',['../_app_data_8cs.html',1,'']]],
  ['appdelegate_2ecs_6',['appdelegate.cs',['../i_o_s_2_app_delegate_8cs.html',1,'(Global Namespace)'],['../_mac_catalyst_2_app_delegate_8cs.html',1,'(Global Namespace)']]],
  ['appshell_2examl_2ecs_7',['AppShell.xaml.cs',['../_app_shell_8xaml_8cs.html',1,'']]]
];
