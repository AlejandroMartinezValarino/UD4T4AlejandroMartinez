var searchData=
[
  ['register_0',['Register',['../class_u_d4_t4_alejandro_martinez_1_1_m_v_v_m_1_1_views_1_1_register.html',1,'UD4T4AlejandroMartinez::MVVM::Views']]],
  ['resource_1',['Resource',['../class_u_d4_t4_alejandro_martinez_1_1_resource.html',1,'UD4T4AlejandroMartinez']]]
];
