var searchData=
[
  ['name_0',['Name',['../class_u_d4_t4_alejandro_martinez_1_1_u_d4_t4_alejandro_martinez___xaml_type_info_1_1_xaml_member.html#af94cf719cd38a9af475b0a4788c17d06',1,'UD4T4AlejandroMartinez::UD4T4AlejandroMartinez_XamlTypeInfo::XamlMember']]],
  ['nombre_1',['nombre',['../class_u_d4_t4_alejandro_martinez_1_1_m_v_v_m_1_1_models_1_1_alumno.html#a1897959c94c1709766e50ea553c91a9c',1,'UD4T4AlejandroMartinez.MVVM.Models.Alumno.Nombre'],['../class_u_d4_t4_alejandro_martinez_1_1_m_v_v_m_1_1_models_1_1_profesor.html#a8c22b3484034c64b9028a8b6c6fbcb85',1,'UD4T4AlejandroMartinez.MVVM.Models.Profesor.Nombre']]],
  ['numerosemana_2',['NumeroSemana',['../class_u_d4_t4_alejandro_martinez_1_1_m_v_v_m_1_1_models_1_1_semana.html#a04f08993aeacf725f54ee0c996e46ca1',1,'UD4T4AlejandroMartinez::MVVM::Models::Semana']]]
];
