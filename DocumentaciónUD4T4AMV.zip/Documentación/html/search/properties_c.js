var searchData=
[
  ['semana_0',['Semana',['../class_u_d4_t4_alejandro_martinez_1_1_m_v_v_m_1_1_view_models_1_1_dia_view_model.html#aa571757ca5e4f28899650eb701dd62c7',1,'UD4T4AlejandroMartinez::MVVM::ViewModels::DiaViewModel']]],
  ['semanas_1',['Semanas',['../class_u_d4_t4_alejandro_martinez_1_1_m_v_v_m_1_1_models_1_1_alumno.html#a48b600ac48936d6f75dac14290d9c02b',1,'UD4T4AlejandroMartinez::MVVM::Models::Alumno']]],
  ['setter_2',['Setter',['../class_u_d4_t4_alejandro_martinez_1_1_u_d4_t4_alejandro_martinez___xaml_type_info_1_1_xaml_member.html#a77e32c6824b5073321ac88cfa7f05962',1,'UD4T4AlejandroMartinez::UD4T4AlejandroMartinez_XamlTypeInfo::XamlMember']]]
];
