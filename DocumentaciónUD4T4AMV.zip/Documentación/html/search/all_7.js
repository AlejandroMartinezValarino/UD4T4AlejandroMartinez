var searchData=
[
  ['fotopath_0',['FotoPath',['../class_u_d4_t4_alejandro_martinez_1_1_m_v_v_m_1_1_models_1_1_alumno.html#a5ebe2c1950a93cbf50dcb6e18c2fdafc',1,'UD4T4AlejandroMartinez::MVVM::Models::Alumno']]],
  ['fullname_1',['FullName',['../class_u_d4_t4_alejandro_martinez_1_1_u_d4_t4_alejandro_martinez___xaml_type_info_1_1_xaml_system_base_type.html#a902dbb71edd872497bc22e3e8ad4ec55',1,'UD4T4AlejandroMartinez::UD4T4AlejandroMartinez_XamlTypeInfo::XamlSystemBaseType']]]
];
