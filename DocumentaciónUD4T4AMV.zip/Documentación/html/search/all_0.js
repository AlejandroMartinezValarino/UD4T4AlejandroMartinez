var searchData=
[
  ['_2enetcoreapp_2cversion_3dv8_2e0_2eassemblyattributes_2ecs_0',['.netcoreapp,version=v8.0.assemblyattributes.cs',['../net8_80-android_2_8_n_e_t_core_app_00_version_0av8_80_8_assembly_attributes_8cs.html',1,'(Global Namespace)'],['../net8_80-ios_2iossimulator-x64_2_8_n_e_t_core_app_00_version_0av8_80_8_assembly_attributes_8cs.html',1,'(Global Namespace)'],['../net8_80-maccatalyst_2maccatalyst-x64_2_8_n_e_t_core_app_00_version_0av8_80_8_assembly_attributes_8cs.html',1,'(Global Namespace)'],['../net8_80-windows10_80_819041_80_2win10-x64_2_8_n_e_t_core_app_00_version_0av8_80_8_assembly_attributes_8cs.html',1,'(Global Namespace)']]]
];
