var searchData=
[
  ['name_0',['Name',['../class_u_d4_t4_alejandro_martinez_1_1_u_d4_t4_alejandro_martinez___xaml_type_info_1_1_xaml_member.html#af94cf719cd38a9af475b0a4788c17d06',1,'UD4T4AlejandroMartinez::UD4T4AlejandroMartinez_XamlTypeInfo::XamlMember']]],
  ['newfile_1',['newFile',['../class_u_d4_t4_alejandro_martinez_1_1_m_v_v_m_1_1_views_1_1_register.html#a07e73dd1858aeaf9405f033ddcff7eea',1,'UD4T4AlejandroMartinez::MVVM::Views::Register']]],
  ['nfloat_2',['nfloat',['../net8_80-ios_2iossimulator-x64_2_u_d4_t4_alejandro_martinez_8nfloat_8g_8cs.html#a5a9fdee2373fc925da61b334ab3b1fda',1,'nfloat:&#160;UD4T4AlejandroMartinez.nfloat.g.cs'],['../net8_80-maccatalyst_2maccatalyst-x64_2_u_d4_t4_alejandro_martinez_8nfloat_8g_8cs.html#a5a9fdee2373fc925da61b334ab3b1fda',1,'nfloat:&#160;UD4T4AlejandroMartinez.nfloat.g.cs']]],
  ['nombre_3',['nombre',['../class_u_d4_t4_alejandro_martinez_1_1_m_v_v_m_1_1_models_1_1_alumno.html#a1897959c94c1709766e50ea553c91a9c',1,'UD4T4AlejandroMartinez.MVVM.Models.Alumno.Nombre'],['../class_u_d4_t4_alejandro_martinez_1_1_m_v_v_m_1_1_models_1_1_profesor.html#a8c22b3484034c64b9028a8b6c6fbcb85',1,'UD4T4AlejandroMartinez.MVVM.Models.Profesor.Nombre']]],
  ['numerosemana_4',['NumeroSemana',['../class_u_d4_t4_alejandro_martinez_1_1_m_v_v_m_1_1_models_1_1_semana.html#a04f08993aeacf725f54ee0c996e46ca1',1,'UD4T4AlejandroMartinez::MVVM::Models::Semana']]]
];
