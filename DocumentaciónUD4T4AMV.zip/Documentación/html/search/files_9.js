var searchData=
[
  ['semana_2ecs_0',['Semana.cs',['../_semana_8cs.html',1,'']]],
  ['student_2examl_2ecs_1',['Student.xaml.cs',['../_student_8xaml_8cs.html',1,'']]]
];
