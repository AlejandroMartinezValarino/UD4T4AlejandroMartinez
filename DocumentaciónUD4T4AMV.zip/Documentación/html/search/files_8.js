var searchData=
[
  ['register_2examl_2ecs_0',['Register.xaml.cs',['../_register_8xaml_8cs.html',1,'']]]
];
