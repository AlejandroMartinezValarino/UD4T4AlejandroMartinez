var searchData=
[
  ['printalumno_0',['PrintAlumno',['../class_u_d4_t4_alejandro_martinez_1_1_m_v_v_m_1_1_view_models_1_1_alumno_view_model.html#a56b86537396e5af5d1e75f1eb2daef6d',1,'UD4T4AlejandroMartinez::MVVM::ViewModels::AlumnoViewModel']]],
  ['processstudenttemplatepdf_1',['ProcessStudentTemplatePDF',['../class_u_d4_t4_alejandro_martinez_1_1_m_v_v_m_1_1_view_models_1_1_alumno_view_model.html#a58d10214b533c059c942eafd9e220b51',1,'UD4T4AlejandroMartinez::MVVM::ViewModels::AlumnoViewModel']]]
];
