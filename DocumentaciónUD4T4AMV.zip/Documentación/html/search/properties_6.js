var searchData=
[
  ['getter_0',['Getter',['../class_u_d4_t4_alejandro_martinez_1_1_u_d4_t4_alejandro_martinez___xaml_type_info_1_1_xaml_member.html#a498da073d42dcfbc04eaecfcb011ef8a',1,'UD4T4AlejandroMartinez::UD4T4AlejandroMartinez_XamlTypeInfo::XamlMember']]],
  ['grado_1',['Grado',['../class_u_d4_t4_alejandro_martinez_1_1_m_v_v_m_1_1_models_1_1_alumno.html#af074c97059b7e08e3961a19eae22fe0b',1,'UD4T4AlejandroMartinez::MVVM::Models::Alumno']]]
];
