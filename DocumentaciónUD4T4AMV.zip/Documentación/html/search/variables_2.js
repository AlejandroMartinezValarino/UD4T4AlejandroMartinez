var searchData=
[
  ['imagenseleccionada_0',['imagenSeleccionada',['../class_u_d4_t4_alejandro_martinez_1_1_m_v_v_m_1_1_views_1_1_register.html#a5fd0123b99c1d6abb2ad290aa1f00eb1',1,'UD4T4AlejandroMartinez::MVVM::Views::Register']]]
];
