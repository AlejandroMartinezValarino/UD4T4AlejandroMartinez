var searchData=
[
  ['boxinstancemethod_0',['BoxInstanceMethod',['../namespace_u_d4_t4_alejandro_martinez_1_1_u_d4_t4_alejandro_martinez___xaml_type_info.html#a49b4ef1e37d57a98f47b9e22fd915215',1,'UD4T4AlejandroMartinez::UD4T4AlejandroMartinez_XamlTypeInfo']]],
  ['boxtype_3c_20t_20_3e_1',['BoxType&lt; T &gt;',['../class_u_d4_t4_alejandro_martinez_1_1_u_d4_t4_alejandro_martinez___xaml_type_info_1_1_xaml_user_type.html#a0c63bbd0b1e3b9f7415f509dcad8e941',1,'UD4T4AlejandroMartinez::UD4T4AlejandroMartinez_XamlTypeInfo::XamlUserType']]]
];
