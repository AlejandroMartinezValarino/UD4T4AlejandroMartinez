var searchData=
[
  ['printcommand_0',['PrintCommand',['../class_u_d4_t4_alejandro_martinez_1_1_m_v_v_m_1_1_view_models_1_1_alumno_view_model.html#afed95ff4c906c776436565c6c29c1bbc',1,'UD4T4AlejandroMartinez::MVVM::ViewModels::AlumnoViewModel']]],
  ['profesorseguimiento_1',['ProfesorSeguimiento',['../class_u_d4_t4_alejandro_martinez_1_1_m_v_v_m_1_1_models_1_1_alumno.html#afe5fed793d15d0f379ae7104dd674479',1,'UD4T4AlejandroMartinez::MVVM::Models::Alumno']]],
  ['provider_2',['Provider',['../class_u_d4_t4_alejandro_martinez_1_1_u_d4_t4_alejandro_martinez___xaml_type_info_1_1_xaml_meta_data_provider.html#a5ec2112dfd03261fa23624b943ad091c',1,'UD4T4AlejandroMartinez::UD4T4AlejandroMartinez_XamlTypeInfo::XamlMetaDataProvider']]]
];
