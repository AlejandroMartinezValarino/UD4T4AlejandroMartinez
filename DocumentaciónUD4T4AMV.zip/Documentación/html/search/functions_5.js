var searchData=
[
  ['initializecomponent_0',['InitializeComponent',['../class_u_d4_t4_alejandro_martinez_1_1_win_u_i_1_1_app.html#ab4c2a8c1d5221273dddbd524c836fe10',1,'UD4T4AlejandroMartinez::WinUI::App']]],
  ['inittypetables_1',['InitTypeTables',['../class_u_d4_t4_alejandro_martinez_1_1_u_d4_t4_alejandro_martinez___xaml_type_info_1_1_xaml_type_info_provider.html#a7be32f2c84fc2cb8f51ad45429a8628f',1,'UD4T4AlejandroMartinez::UD4T4AlejandroMartinez_XamlTypeInfo::XamlTypeInfoProvider']]]
];
